from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Cliente, Venda

class ClienteListView(ListView):
    model = Cliente
    template_name = 'clientes/lista.html'

class ClienteCreateView(CreateView):
    model = Cliente
    fields = '__all__'
    template_name = 'clientes/form.html'
    success_url = reverse_lazy('cliente-list')

# Repete pra UpdateView e DeleteView

class VendaListView(ListView):
    model = Venda
    template_name = 'vendas/lista.html'

    def get_queryset(self):
        queryset = super().get_queryset()
        cliente = self.request.GET.get('cliente')
        data_inicio = self.request.GET.get('inicio')
        data_fim = self.request.GET.get('fim')

        if cliente:
            queryset = queryset.filter(cliente__nome__icontains=cliente)
        if data_inicio and data_fim:
            queryset = queryset.filter(data_venda__range=[data_inicio, data_fim])

        return queryset
